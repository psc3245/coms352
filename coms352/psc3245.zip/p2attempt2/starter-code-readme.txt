Modify journal.c with your implementation and block_service.c with testing code.

Do not modify journal.h.

To run the code, use the command:
make